"use client";

import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";
import Link from "next/link";
import Image from "next/image";

export default function SplashPage() {
  const router = useRouter();
  const [checking, setChecking] = useState(true);

  useEffect(() => {
    const stored = localStorage.getItem("spot_user");
    if (stored) {
      // Already logged in → go to the app
      router.replace("/app");
    } else {
      setChecking(false);
    }
  }, [router]);

  if (checking) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-950">
        <div className="h-8 w-8 animate-pulse rounded-full bg-indigo-500/40" />
      </div>
    );
  }

  return (
    <div className="relative flex min-h-screen flex-col items-center justify-center overflow-hidden bg-zinc-950 px-6">
      {/* Soft background glow */}
      <div className="pointer-events-none absolute inset-0">
        <div className="absolute left-1/2 top-1/3 h-96 w-96 -translate-x-1/2 -translate-y-1/2 rounded-full bg-indigo-600/20 blur-3xl" />
        <div className="absolute bottom-1/4 right-1/4 h-64 w-64 rounded-full bg-teal-500/10 blur-3xl" />
      </div>

      <main className="relative z-10 flex w-full max-w-md flex-col items-center text-center">
        {/* Logo */}
        <div className="mb-8">
          <Image
            src="/spot-logo.png"
            alt="Spot logo"
            width={180}
            height={180}
            className="drop-shadow-2xl"
            priority
          />
        </div>

        {/* Brand name + slogan */}
        <h1 className="mb-3 text-5xl font-bold tracking-tight text-white">
          Spot
        </h1>
        <p className="mb-10 max-w-xs text-lg leading-relaxed text-zinc-400">
          bringing friends together more often
        </p>

        {/* CTA buttons */}
        <div className="flex w-full flex-col gap-3 sm:flex-row sm:justify-center">
          <Link
            href="/login"
            className="rounded-2xl bg-gradient-to-r from-indigo-600 to-teal-500 px-8 py-3.5 text-sm font-semibold text-white shadow-lg shadow-indigo-500/25 transition hover:from-indigo-500 hover:to-teal-400"
          >
            Get started
          </Link>
          <Link
            href="/login"
            className="rounded-2xl border border-zinc-700 bg-zinc-900/60 px-8 py-3.5 text-sm font-medium text-zinc-300 transition hover:border-zinc-500 hover:bg-zinc-800"
          >
            Log in
          </Link>
        </div>

        {/* Tiny tagline */}
        <p className="mt-12 text-xs text-zinc-600">
          Private by design · Friends added manually
        </p>
      </main>
    </div>
  );
}
