"use client";

import { useState, useMemo, useEffect } from "react";
import { useRouter } from "next/navigation";

// Distance buckets in miles
const DISTANCE_BUCKETS = [0.25, 0.5, 1, 2, 5, 10, 20, 30];

type Friend = {
  id: string;
  name: string;
  distanceMiles: number | null;
  lastSeen: string;
  isOnline: boolean;
  avatarColor: string;
};

const MOCK_FRIENDS: Friend[] = [
  { id: "1", name: "Alex Rivera", distanceMiles: 0.18, lastSeen: "Just now", isOnline: true, avatarColor: "bg-blue-500" },
  { id: "2", name: "Jordan Lee", distanceMiles: 0.42, lastSeen: "2 min ago", isOnline: true, avatarColor: "bg-emerald-500" },
  { id: "3", name: "Sam Patel", distanceMiles: 0.9, lastSeen: "5 min ago", isOnline: false, avatarColor: "bg-violet-500" },
  { id: "4", name: "Taylor Kim", distanceMiles: 1.4, lastSeen: "12 min ago", isOnline: true, avatarColor: "bg-amber-500" },
  { id: "5", name: "Casey Nguyen", distanceMiles: 3.2, lastSeen: "1 hr ago", isOnline: false, avatarColor: "bg-rose-500" },
  { id: "6", name: "Morgan Brooks", distanceMiles: 7.8, lastSeen: "3 hr ago", isOnline: false, avatarColor: "bg-cyan-500" },
  { id: "7", name: "Riley Chen", distanceMiles: 15, lastSeen: "Yesterday", isOnline: false, avatarColor: "bg-indigo-500" },
  { id: "8", name: "Quinn Morales", distanceMiles: 28, lastSeen: "2 days ago", isOnline: false, avatarColor: "bg-pink-500" },
  { id: "9", name: "Avery Torres", distanceMiles: null, lastSeen: "Location off", isOnline: false, avatarColor: "bg-slate-500" },
  { id: "10", name: "Jamie Park", distanceMiles: 45, lastSeen: "Last week", isOnline: false, avatarColor: "bg-teal-500" },
];

function getBucketLabel(miles: number): string {
  if (miles <= 0.25) return "≤ 0.25 mi";
  if (miles <= 0.5) return "≤ 0.5 mi";
  if (miles <= 1) return "≤ 1 mi";
  if (miles <= 2) return "≤ 2 mi";
  if (miles <= 5) return "≤ 5 mi";
  if (miles <= 10) return "≤ 10 mi";
  if (miles <= 20) return "≤ 20 mi";
  if (miles <= 30) return "≤ 30 mi";
  return "> 30 mi";
}

function getInitials(name: string) {
  return name
    .split(" ")
    .map((n) => n[0])
    .join("")
    .slice(0, 2)
    .toUpperCase();
}

export default function AppPage() {
  const router = useRouter();
  const [user, setUser] = useState<{ email: string; name: string } | null>(null);
  const [search, setSearch] = useState("");
  const [activeTab, setActiveTab] = useState<"radius" | "all">("radius");
  const [selectedFriend, setSelectedFriend] = useState<Friend | null>(null);
  const [showAddFriend, setShowAddFriend] = useState(false);
  const [newFriendName, setNewFriendName] = useState("");

  useEffect(() => {
    const stored = localStorage.getItem("spot_user");
    if (stored) {
      try {
        setUser(JSON.parse(stored));
      } catch {
        router.push("/login");
      }
    } else {
      router.push("/login");
    }
  }, [router]);

  const filteredFriends = useMemo(() => {
    if (!search.trim()) return MOCK_FRIENDS;
    const q = search.toLowerCase();
    return MOCK_FRIENDS.filter((f) => f.name.toLowerCase().includes(q));
  }, [search]);

  const radiusGroups = useMemo(() => {
    const groups: { label: string; friends: Friend[] }[] = [];
    const used = new Set<string>();

    for (const bucket of DISTANCE_BUCKETS) {
      const label = getBucketLabel(bucket);
      const inBucket = filteredFriends.filter(
        (f) =>
          f.distanceMiles !== null &&
          f.distanceMiles <= bucket &&
          !used.has(f.id)
      );
      inBucket.forEach((f) => used.add(f.id));
      if (inBucket.length > 0) {
        groups.push({ label, friends: inBucket });
      }
    }

    const farther = filteredFriends.filter(
      (f) => f.distanceMiles !== null && f.distanceMiles > 30 && !used.has(f.id)
    );
    if (farther.length > 0) {
      groups.push({ label: "> 30 mi", friends: farther });
    }

    const unknown = filteredFriends.filter((f) => f.distanceMiles === null);
    if (unknown.length > 0) {
      groups.push({ label: "Location unknown", friends: unknown });
    }

    return groups;
  }, [filteredFriends]);

  const handleLogout = () => {
    localStorage.removeItem("spot_user");
    router.push("/");
  };

  if (!user) {
    return (
      <div className="flex min-h-screen items-center justify-center bg-zinc-950">
        <p className="text-zinc-400">Loading…</p>
      </div>
    );
  }

  return (
    <div className="flex h-screen flex-col bg-zinc-950 text-zinc-100">
      {/* Header */}
      <header className="flex items-center justify-between border-b border-zinc-800 px-4 py-3">
        <div className="flex items-center gap-3">
          <div className="flex h-9 w-9 items-center justify-center rounded-xl bg-gradient-to-br from-indigo-500 to-teal-400 text-sm font-bold text-white shadow-md shadow-indigo-500/20">
            S
          </div>
          <div>
            <h1 className="text-lg font-semibold tracking-tight">Spot</h1>
            <p className="text-xs text-zinc-400">Hey, {user.name}</p>
          </div>
        </div>
        <div className="flex items-center gap-2">
          <button
            onClick={() => setShowAddFriend(true)}
            className="rounded-full bg-indigo-600 px-3 py-1.5 text-xs font-medium hover:bg-indigo-500"
          >
            + Add Friend
          </button>
          <button
            onClick={handleLogout}
            className="rounded-full bg-zinc-800 px-3 py-1.5 text-xs font-medium text-zinc-300 hover:bg-zinc-700"
          >
            Log out
          </button>
        </div>
      </header>

      {/* Mobile tab switcher */}
      <div className="flex border-b border-zinc-800 md:hidden">
        <button
          onClick={() => setActiveTab("radius")}
          className={`flex-1 py-2.5 text-sm font-medium ${
            activeTab === "radius"
              ? "border-b-2 border-indigo-500 text-indigo-400"
              : "text-zinc-400"
          }`}
        >
          By Radius
        </button>
        <button
          onClick={() => setActiveTab("all")}
          className={`flex-1 py-2.5 text-sm font-medium ${
            activeTab === "all"
              ? "border-b-2 border-indigo-500 text-indigo-400"
              : "text-zinc-400"
          }`}
        >
          All Friends
        </button>
      </div>

      {/* Main content */}
      <div className="flex flex-1 overflow-hidden">
        {/* Left column – Radius */}
        <section
          className={`flex w-full flex-col border-r border-zinc-800 md:w-1/2 ${
            activeTab === "all" ? "hidden md:flex" : "flex"
          }`}
        >
          <div className="border-b border-zinc-800 px-4 py-3">
            <h2 className="text-sm font-semibold text-zinc-300">Nearby by Radius</h2>
            <p className="text-xs text-zinc-500">Friends grouped by distance from you</p>
          </div>
          <div className="flex-1 overflow-y-auto">
            {radiusGroups.length === 0 ? (
              <p className="p-4 text-sm text-zinc-500">No friends match.</p>
            ) : (
              radiusGroups.map((group) => (
                <div key={group.label} className="border-b border-zinc-900">
                  <div className="sticky top-0 bg-zinc-900/90 px-4 py-2 text-xs font-semibold uppercase tracking-wider text-indigo-400 backdrop-blur">
                    {group.label} · {group.friends.length}
                  </div>
                  <ul>
                    {group.friends.map((friend) => (
                      <FriendRow
                        key={friend.id}
                        friend={friend}
                        onSelect={() => setSelectedFriend(friend)}
                        selected={selectedFriend?.id === friend.id}
                      />
                    ))}
                  </ul>
                </div>
              ))
            )}
          </div>
        </section>

        {/* Right column – All Friends */}
        <section
          className={`flex w-full flex-col md:w-1/2 ${
            activeTab === "radius" ? "hidden md:flex" : "flex"
          }`}
        >
          <div className="border-b border-zinc-800 px-4 py-3">
            <h2 className="text-sm font-semibold text-zinc-300">All Friends</h2>
            <div className="mt-2">
              <input
                type="search"
                placeholder="Search friends…"
                value={search}
                onChange={(e) => setSearch(e.target.value)}
                className="w-full rounded-lg border border-zinc-700 bg-zinc-900 px-3 py-2 text-sm outline-none placeholder:text-zinc-500 focus:border-indigo-500"
              />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto">
            {filteredFriends.length === 0 ? (
              <p className="p-4 text-sm text-zinc-500">No friends found.</p>
            ) : (
              <ul>
                {filteredFriends.map((friend) => (
                  <FriendRow
                    key={friend.id}
                    friend={friend}
                    onSelect={() => setSelectedFriend(friend)}
                    selected={selectedFriend?.id === friend.id}
                    showDistance
                  />
                ))}
              </ul>
            )}
          </div>
        </section>
      </div>

      {/* Chat panel placeholder */}
      {selectedFriend && (
        <div className="fixed inset-x-0 bottom-0 z-20 border-t border-zinc-700 bg-zinc-900 p-4 md:inset-auto md:bottom-4 md:right-4 md:w-80 md:rounded-xl md:border md:shadow-2xl">
          <div className="mb-3 flex items-center justify-between">
            <div className="flex items-center gap-3">
              <div
                className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-semibold text-white ${selectedFriend.avatarColor}`}
              >
                {getInitials(selectedFriend.name)}
              </div>
              <div>
                <p className="font-medium">{selectedFriend.name}</p>
                <p className="text-xs text-zinc-400">
                  {selectedFriend.distanceMiles !== null
                    ? `${selectedFriend.distanceMiles.toFixed(1)} mi away`
                    : "Location unknown"}{" "}
                  · {selectedFriend.lastSeen}
                </p>
              </div>
            </div>
            <button
              onClick={() => setSelectedFriend(null)}
              className="rounded-full p-1 text-zinc-400 hover:bg-zinc-800 hover:text-white"
            >
              ✕
            </button>
          </div>
          <div className="mb-3 rounded-lg bg-zinc-800 p-3 text-sm text-zinc-400">
            Messaging coming soon.
          </div>
          <div className="flex gap-2">
            <input
              type="text"
              placeholder="Type a message…"
              className="flex-1 rounded-lg border border-zinc-700 bg-zinc-950 px-3 py-2 text-sm outline-none focus:border-indigo-500"
              disabled
            />
            <button
              disabled
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium opacity-50"
            >
              Send
            </button>
          </div>
        </div>
      )}

      {/* Add Friend modal */}
      {showAddFriend && (
        <div className="fixed inset-0 z-30 flex items-center justify-center bg-black/60 p-4">
          <div className="w-full max-w-sm rounded-2xl border border-zinc-700 bg-zinc-900 p-6 shadow-2xl">
            <h3 className="mb-1 text-lg font-semibold">Add a friend</h3>
            <p className="mb-4 text-sm text-zinc-400">
              Manual add only for now. Enter their name.
            </p>
            <input
              type="text"
              value={newFriendName}
              onChange={(e) => setNewFriendName(e.target.value)}
              placeholder="Friend’s name"
              className="mb-4 w-full rounded-xl border border-zinc-700 bg-zinc-950 px-4 py-3 text-sm outline-none focus:border-indigo-500"
              autoFocus
            />
            <div className="flex gap-2">
              <button
                onClick={() => {
                  setShowAddFriend(false);
                  setNewFriendName("");
                }}
                className="flex-1 rounded-xl bg-zinc-800 py-2.5 text-sm font-medium hover:bg-zinc-700"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setShowAddFriend(false);
                  setNewFriendName("");
                  alert("Friend add will be connected to the database next.");
                }}
                className="flex-1 rounded-xl bg-indigo-600 py-2.5 text-sm font-medium hover:bg-indigo-500"
              >
                Add
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function FriendRow({
  friend,
  onSelect,
  selected,
  showDistance = false,
}: {
  friend: Friend;
  onSelect: () => void;
  selected: boolean;
  showDistance?: boolean;
}) {
  return (
    <li>
      <button
        onClick={onSelect}
        className={`flex w-full items-center gap-3 px-4 py-3 text-left transition-colors hover:bg-zinc-900 ${
          selected ? "bg-zinc-900/80" : ""
        }`}
      >
        <div className="relative">
          <div
            className={`flex h-10 w-10 items-center justify-center rounded-full text-sm font-semibold text-white ${friend.avatarColor}`}
          >
            {getInitials(friend.name)}
          </div>
          {friend.isOnline && (
            <span className="absolute bottom-0 right-0 h-3 w-3 rounded-full border-2 border-zinc-950 bg-emerald-400" />
          )}
        </div>
        <div className="min-w-0 flex-1">
          <p className="truncate font-medium">{friend.name}</p>
          <p className="truncate text-xs text-zinc-400">
            {showDistance && friend.distanceMiles !== null
              ? `${friend.distanceMiles.toFixed(1)} mi · `
              : ""}
            {friend.lastSeen}
          </p>
        </div>
        {friend.distanceMiles !== null && !showDistance && (
          <span className="rounded-full bg-zinc-800 px-2 py-0.5 text-xs text-zinc-300">
            {friend.distanceMiles < 1
              ? `${(friend.distanceMiles * 5280).toFixed(0)} ft`
              : `${friend.distanceMiles.toFixed(1)} mi`}
          </span>
        )}
      </button>
    </li>
  );
}
